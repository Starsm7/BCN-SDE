import ot
import torch
from torch import optim, nn
import numpy as np
from geomloss import SamplesLoss
import tqdm
from src.model import ForwardSDE
import os
from src.config_Veres import load_data

# 数据采样函数
def p_samp(p, num_samp, w=None):
    repflag = p.shape[0] < num_samp
    p_sub = np.random.choice(p.shape[0], size=num_samp, replace=repflag)
    if w is None:
        w_ = torch.ones(len(p_sub))
    else:
        w_ = w[p_sub].clone()
    w_ = w_ / w_.sum()
    return p[p_sub, :].clone(), w_

def init_device(args):
    args.cuda = args.use_cuda and torch.cuda.is_available()
    device = torch.device('cuda:{}'.format(args.device) if args.cuda else 'cpu')
    return device

# ---- loss
class OTLoss():

    def __init__(self, config, device):
        self.ot_solver = SamplesLoss("sinkhorn", p=2, blur=config.sinkhorn_blur,
                                     scaling=config.sinkhorn_scaling, debias=True)
        self.device = device

    def __call__(self, a_i, x_i, b_j, y_j, requires_grad=True):
        a_i = a_i.to(self.device)
        x_i = x_i.to(self.device)
        b_j = b_j.to(self.device)
        y_j = y_j.to(self.device)

        if requires_grad:
            a_i.requires_grad_()
            x_i.requires_grad_()
            b_j.requires_grad_()

        loss_xy = self.ot_solver(a_i, x_i, b_j, y_j)
        return loss_xy
class OT_loss1(nn.Module):
    _valid = 'emd sinkhorn sinkhorn_knopp_unbalanced'.split()
    def __init__(self, which='emd', use_cuda=True):
        if which not in self._valid:
            raise ValueError(f'{which} not known ({self._valid})')
        self.which = which
        self.use_cuda = use_cuda
    def __call__(self, mu, source, nu, target, device='cuda', sigma=None, use_cuda=None):
        if use_cuda is None:
            use_cuda = self.use_cuda
        if not isinstance(mu, torch.Tensor):
            mu = torch.tensor(mu, dtype=torch.float32)
        if not isinstance(nu, torch.Tensor):
            nu = torch.tensor(nu, dtype=torch.float32)
        if use_cuda:
            mu = mu.to(device)
            nu = nu.to(device)
            target = target.to(device)
        M = torch.cdist(source, target) ** 2
        if self.which == 'emd':
            pi = ot.emd(mu.detach().cpu().numpy(), nu.detach().cpu().numpy(), M.detach().cpu().numpy())
        elif self.which == 'sinkhorn':
            if sigma is None:
                raise ValueError('sigma must be provided for sinkhorn method')
            pi = ot.sinkhorn(mu, nu, M, sigma)
        elif self.which == 'sinkhorn_knopp_unbalanced':
            if sigma is None:
                raise ValueError('sigma must be provided for sinkhorn_knopp_unbalanced method')
            pi = ot.unbalanced.sinkhorn_knopp_unbalanced(mu.detach().cpu().numpy(), nu.detach().cpu().numpy(),
                                                         M.detach().cpu().numpy(), sigma, sigma)
        else:
            raise ValueError(f'{self.which} not known ({self._valid})')

        if isinstance(pi, np.ndarray):
            pi = torch.tensor(pi, dtype=torch.float32)
        elif isinstance(pi, torch.Tensor):
            pi = pi.clone().detach()
        pi = pi.to(device) if use_cuda else pi
        M = M.to(pi.device)
        loss = torch.sum(pi * M)
        return loss

def run_leaveout(args,initial_config):
    # ---- initialize
    device = init_device(args)
    args.task = 'leaveout'
    Train_ts = args.train_t

    args.train_t = list(sorted(set(Train_ts)))
    print('--------------------------------------------')
    print('----------train_t=', args.train_t)
    print('--------------------------------------------')

    config = initial_config(args)
    x, y, config = load_data(config)

    if os.path.exists(os.path.join(config.out_dir, 'train.epoch_003000.pt')):
        print(os.path.join(config.out_dir, 'train.epoch_003000.pt'), ' exists. Skipping.')

    else:

        # 创建模型
        model = ForwardSDE(config)
        model.to(device)
        # 加载预训练权重，忽略不匹配的参数
        pretrained_dict = torch.load('RESULTS/seed0/train.best.pt',
                                     map_location=device)['model_state_dict']
        model_dict = model.state_dict()
        # 1. 过滤掉不匹配的键
        pretrained_dict = {k: v for k, v in pretrained_dict.items() if k in model_dict}
        # 2. 更新当前模型的state_dict
        model_dict.update(pretrained_dict)
        # 3. 加载过滤后的state_dict
        model.load_state_dict(model_dict)
        # 冻结所有加载的参数
        for name, param in model.named_parameters():
            if name in pretrained_dict:  # 只冻结那些从预训练模型加载的参数
                param.requires_grad = False
        # 验证冻结情况
        for name, param in model.named_parameters():
            print(f"{name}: {'冻结' if not param.requires_grad else '可训练'}")


        loss = OTLoss(config, device)
        # loss = OT_loss1()
        torch.save(config.__dict__, config.config_pt)

        optimizer = optim.Adam(list(model.parameters()), lr=config.train_lr)
        scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=100, gamma=0.5)
        optimizer.zero_grad()

        pbar = tqdm.tqdm(range(config.train_epochs))

        best_train_loss_xy = np.inf

        with open(config.train_log, 'w') as log_handle:
            for epoch in pbar:
                losses_xy = []
                config.train_epoch = epoch
                dat_prev = x[config.start_t]
                x_i, a_i = p_samp(dat_prev, int(dat_prev.shape[0] * args.train_batch))
                x_i = x_i.to(device)
                ts = [0] + Train_ts
                y_ts = [np.float64(y[ts_i]) for ts_i in ts]
                x_r_s = model(y_ts, x_i)

                for j in config.train_t:
                    t_cur = j
                    dat_cur = x[t_cur]
                    y_j, b_j = p_samp(dat_cur, int(dat_cur.shape[0] * args.train_batch))
                    position = Train_ts.index(j)
                    loss_xy = loss(a_i, x_r_s[position+1], b_j, y_j)
                    losses_xy.append(loss_xy.item())
                    loss_xy.backward(retain_graph=True)
                train_loss_xy = np.mean(losses_xy)

                # step
                if config.train_clip > 0:
                    torch.nn.utils.clip_grad_norm_(model.parameters(), config.train_clip)
                optimizer.step()
                scheduler.step()
                model.zero_grad()

                # report

                desc = "[train] {}".format(epoch + 1)
                desc += " {:.6f}".format(train_loss_xy)
                desc += " {:.6f}".format(best_train_loss_xy)
                pbar.set_description(desc)
                log_handle.write(desc + '\n')
                log_handle.flush()

                if train_loss_xy < best_train_loss_xy:
                    best_train_loss_xy = train_loss_xy
                    torch.save({
                        'model_state_dict': model.state_dict(),
                        'epoch': config.train_epoch + 1,
                    }, config.train_pt.format('best'))

                # save model every x epochs

                if (config.train_epoch + 1) % config.save == 0:
                    epoch_ = str(config.train_epoch + 1).rjust(6, '0')
                    torch.save({
                        'model_state_dict': model.state_dict(),
                        'epoch': config.train_epoch + 1,
                    }, config.train_pt.format('epoch_{}'.format(epoch_)))


    return config










