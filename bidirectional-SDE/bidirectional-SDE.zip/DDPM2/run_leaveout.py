import os
import random
import numpy as np
import torch
from src.config_Veres import config, init_config
import src.train as train
from src.evaluation import evaluate_fit

def seed_everything(seed=11):
    random.seed(seed)
    np.random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    os.environ['CUBLAS_WORKSPACE_CONFIG'] = ':16:8'
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms(True)
seed_everything(967)
random_numbers = [2]

for random_number in random_numbers:
    seed_everything(random_number)
    args = config()
    args.seed = random_number
    args.data_path = 'data/fate_train.pt'
    config_train = train.run_leaveout(args, init_config)
    evaluate_fit(config_train, init_config, use_loss='emd')
    torch.cuda.empty_cache()